Read me

ganache-cli -p 3000